You can find the full code for Chapter 6 in:

https://github.com/turnbullpress/tf_dc

