# Our first AWS configuration for Terraform

An initial configuration for Terraform.

## Usage

```
$ terraform apply
```

## License

MIT
